import React from "react";
import { Link, Router } from "react-router-dom";
export function Registersuccess(){
    return(<>
  <h1 style={{paddingTop:150}}>REGISTERED SUCCESSFULLY</h1>  
  <center>
  
    <Link to="/student/Login">Login Here</Link>
    
   </center>
    </>)
}