import React from "react";
import *as FcIcons from 'react-icons/fc';
import { IconContext, icons } from "react-icons/lib";


export function Vision(){
 //   const icon ={icon:<FcIcons.FcFlashOn/>}

 const data = [ "Equity", "Transparency",  "Creativity","Team Work",  "Environment Sustainability"," Staff Development"," Women in Development"]
    return(<>


    <div style={{paddingLeft:200}}>
     <center>  <h1 > OUR VISION HAS TO DEVELOP COMPETITIVE WORKFORCE </h1></center><br/>
     
     <IconContext.Provider value={{ className: "shared-class", size: 100,justifyContent:'center' }}>
     <FcIcons.FcPositiveDynamic/>    <h3>For that we will work on </h3>
        </IconContext.Provider>
        </div>


    <div style={{paddingLeft:100}}>
            {
                data.map((datas)=><div style={{paddingLeft:400,paddingRight:300}}><FcIcons.FcFlashOn/>{datas}</div>)
            }
            </div>
    </>)
}