import React,{useState} from "react";
import image from './Backimage.jpg';

export default function StudentLogin(){

const [email, setEmail] = useState('');
const [password,setPassword] = useState('');

const submitValue = (e) => {
   
const frmdetails = {
    
    'Email' : email,
    'password':password
}
console.log(frmdetails);
e.preventDefault();
}

const style={
   
   
    paddingLeft:400,
    fontSize:25
      
}
return(

<>
<body className="studentlogin">

<h1 style={{paddingTop:50,paddingLeft:30,color:'white'}}>STUDENT LOGIN :</h1>
            <form style={style} onSubmit={submitValue}>
            <div>
                <center>
            <label>Email:  </label> 
            <input type="email"name ="email"  onChange={e => setEmail(e.target.value)}/><br/><br/>
           
            <label>Password: </label> 
            <input type="password"name ="password"  onChange={e => setPassword(e.target.value)}/><br/><br/> 
            <input type="submit" value="submit"/><br></br><br/>
            </center>
            </div><br/>
           
           
            {/* <div id="div1">{this.list}</div> */}
            </form>
            </body>
</>
)
}