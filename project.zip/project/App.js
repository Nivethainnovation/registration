
import Sidebar from "./Sidebar";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import StudentLogin from "./StudentLogin";
import StaffLogin from "./StaffLogin";
import StudentRegister from "./StudentRegister";
import StaffRegister from "./StaffRegister";
import { Registersuccess } from "./Registersuccess";
import { Home } from "./Home";
import { Aim } from "./Aim";
import { Vision } from "./Vision";
import { Footer } from "./Footer";
import { Contact } from "./Contact";
import { Staffsuccess } from "./Staffsuccess";


function App1() {
	
return (
	<Router>
	<Sidebar />
	
	<Routes>
	<Route path='/' element={<Home/>} />
		
		<Route path='/about-us/' element={<Home/>} />
		<Route path='/about-us/aim' element={<Aim/>} />
		<Route path='/about-us/vision' element={<Vision/>} />


		<Route path='/student/' element={<Home/>} />
		<Route path='/student/register' element={<StudentRegister/>} />
		<Route path='/student/Login' element={<StudentLogin/>} />
		<Route path='/student/register/success' element={<Registersuccess/>} />


		<Route path='/staff/' element={<Home/>} />
		<Route path='/staff/Login' element={<StaffLogin/>} />
		<Route path='/staff/register' element={<StaffRegister/>} />
		<Route path='/staff/register/success' element={<Staffsuccess/>} />

		<Route path='/contact' element={<Contact/>} />
		
	</Routes>
	</Router>
);
}

export default App1;
