import logo from './Home.jpg';

import './Home.css'
export function Home(){
    const heading={
        paddingTop:80
    }
    return(<>
    
    <h1 style={heading}>WELCOME !!!!!!!!</h1>
    <img src ={logo} className   ="introimg"alt="Homelogo" width={1300} height={500} ></img>
    <div style={{backgroundColor:'blanchedalmon'}}>
     
        <center>
        <div>
             <p className='course'> COURSES OFFERED:<br/></p>
             
             <p className='coursedata'>
                <p style={{color:'red'}}>UG Programmes</p>
                <li>Mechanical Engineering</li>
             <li> Civil Engineering</li>
             <li> Electronics and Communication Engineering</li>
              <li>Electricals and Electronics Engineering</li> 
            <li> Computer Science Engineering</li>
             <li> Information Technology</li> </p> 
             <br/>
             </div>
<div >
             <p className='coursedata'>
                <p style={{color:'red'}}>PG Programmes</p>
                <li>M.E ( CAD/CAM ) </li>
             <li> M.E ( Embedded System Technologies )  </li>
             <li>M.E ( Computer Science and Engineering ) </li>
              <li> M.E (Communication Systems)</li> 
            <li>M.E (Structural Engineering)</li>
             <li> MCA – Master of Computer Applications</li> </p> 
             </div>
        </center>
    </div>
    </>)
}
