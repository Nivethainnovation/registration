import { IconContext } from 'react-icons';
import * as MdIcons from 'react-icons/md';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';



export function Contact(){
    return(
    <>


         <div style={{fontSize:50,paddingLeft:200}}>

                <div style={{paddingLeft:50}}>
                   <IconContext.Provider value={{ size: 50,color:'blue' }}>
                        <MdIcons.MdShareLocation></MdIcons.MdShareLocation>
                    </IconContext.Provider>
                </div>

                <div style={{fontSize:20,paddingLeft:90}}>
                     <b style={{color:'coral'}}>ADDRESS:</b><br/><br/>
                        ABC COLLEGE of ENGINEERING &TECHNOLOGY,<br/><br/>
                        TAMBARAM,<br/><br/>
                        CHENNAI.<br/>
                </div>                 
       
            </div>

            <br/>

        <div style={{paddingLeft:200}}>
                <div style={{paddingLeft:50}}>
                   <IconContext.Provider value={{ size: 50,color:'blue' }}>
                        <FaIcons.FaPhone />
                   </IconContext.Provider>
                </div>

                <div style={{fontSize:30,paddingLeft:210}}>
                    <b style={{color:'coral'}}>Phone:</b><br/><br/>
                     9632587410<br/><br/>
                     8523697410,<br/><br/>
                     
                </div>
        </div>
        <div style={{paddingLeft:200}}>
                <div style={{paddingLeft:50}}>
                   <IconContext.Provider value={{ size: 50,color:'blue' }}>
                   <AiIcons.AiFillMail/>
                   </IconContext.Provider>
                </div>

                <div style={{fontSize:25,paddingLeft:210}}>
                    <b style={{color:'coral'}}>Mail Us on</b><br/><br/>
                     abctech@abc.com<br/><br/>
                     abccet@abc.com<br/><br/>
                     
                </div>
        </div>
    



            

    {/* <IconContext value={{size:200}}>
         <MdIcons.MdShareLocation/>
     </IconContext> */}
    </>)
}