import * as AiIcons from "react-icons/ai";
export function Footer(){
    return(<>
    <h1
			style={{ 
					marginLeft: "150px",
					marginRight: "410px",
					color: "white" ,
					paddingBottom:30,
                }}>
		<AiIcons.AiFillCopyrightCircle/>	ABC TECHNOLOGY
		</h1>

           </>)
}