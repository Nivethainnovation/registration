import React from "react";
import { IconContext } from "react-icons/lib";
import * as FcIcons from "react-icons/fc";


export function Aim(){
    return(<>
        <div>
        
<IconContext.Provider value={{ className: "shared-class", size: 200,justifyContent:'center' }}>
        <FcIcons.FcGraduationCap></FcIcons.FcGraduationCap>
        <blockquote style={{fontSize:22,paddingLeft:55}} >
             Our Aim is to enhance student skill and update to new technology.<br/><br/>

             In general, an engineering student should strive to acquire knowledge and skills in their field, and apply them to design, develop, and improve systems, processes, and products in a safe, ethical, and sustainable manner. 
             Additionally, an engineering student should also strive to develop their problem-solving, communication, teamwork, and leadership abilities, as well as their creativity and critical thinking skills. These abilities will be beneficial for an engineering student both in their professional and personal life.
             </blockquote>
        </IconContext.Provider>
           
            
             <div>

                </div>
        </div>
    </>)

}