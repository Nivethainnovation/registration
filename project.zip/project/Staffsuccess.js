import React from "react";
import { Link, Router } from "react-router-dom";
export function Staffsuccess(){
    return(<>
  <h1 style={{paddingTop:150}}>REGISTERED SUCCESSFULLY</h1>  
  <center>
  
    <Link to="/staff/Login">Login Here</Link>
    
   </center>
    </>)
}