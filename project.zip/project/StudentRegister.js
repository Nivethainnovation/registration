import React,{useState} from "react";
import { useNavigate } from "react-router-dom";
import a from './Backimage.jpg'

export default function StudentRegister(){
const [name,setName]=useState('');
const [department,setDepartment]=useState('select here');
const [email, setEmail] = useState('');
const [password,setPassword] = useState("");
const [confirmPassword,setconfirmPassword]=useState("");
const [emailError, setEmailError]=useState('');
const [repassworderr,setrepassworderr]=useState('');
const [depterr,setDepterr]=useState('');

const navigate = useNavigate();


const handleemail=(e)=>{
        setEmail(e.target.value);
        if (email==null) {    
            
            setEmailError('Empty :)')
            // document.getElementById("div1").innerHTML='EMPTY';
          }  else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(email))  {
            setEmailError('Enter valid Email!')
            // document.getElementById("div1").innerHTML='Enter valid email';
          }
          else{
            setEmailError('')
            // document.getElementById("div1").innerHTML='Email is valid';
          }

}

const resetpassword=(e)=>{
        
    if (password!==confirmPassword) {
        setrepassworderr('password mismatch') ;
    }
    else{
        setrepassworderr('')
    }

}


const handledept=(e)=>{
   // setDepartment(e.target.value);
    if(department===''){
        setDepterr('Select Department');
}
else{

    setDepterr('');
}
}




const submitValue = (e) => {
   
const frmdetails = {
    
    'Email' : email,
    'password':password,
    'resetPassword':confirmPassword
    
}
if(name==''||department==''||email==''||password==''||confirmPassword=='')
{
    document.getElementById("div3").innerHTML='Enter all the fields';
}
else if(name!==''||department!==''||email!==''||password==!''||confirmPassword==!''){

    if(typeof password !== "undefined" && typeof confirmPassword !== "undefined") {

        if (password!==confirmPassword) {
        setrepassworderr('password mismatch') ;
    }
    else if(password==confirmPassword){
       // setrepassworderr('password match');
        console.log("eligible");
        navigate('/student/register/success');
    }
    }
    
}


console.log(frmdetails);
e.preventDefault();
}

const style={
    
    paddingLeft:410,
    fontSize:20,
    color:'white'
};

const formstyle={
    paddingLeft:'100px'
}
return(
<>
<body className="studentregister">
<h1 style={{paddingTop:50,paddingRight:5,color:'MediumSeaGreen'}}>STUDENT REGISTRATION FORM :</h1>
            <form style={style} onSubmit={submitValue}>
            <div>
               
            <label >  Name:  </label> 
            <input type="text"name ="name"  onChange={e => setName(e.target.value)}/><br/><br/>

            <label    >Department :   </label>
            <select value={department} onBlur={handledept} onChange={e=>setDepartment(e.target.value)}>
                <option value="Mech">Mech</option>
                <option value="Civil">Civil</option>
                <option value="ECE">ECE</option>
                <option value="EEE">EEE</option>
                <option value="CSE">CSE</option>
                <option value="IT">IT</option>
           </select><br/>
           <span  style={{  fontWeight: 'bold',  color: 'red', }}>{depterr}</span><br/>
           <br/>

           <label >  Email :  </label>
           <input type="email"name ="email"  onChange={handleemail}/><br/><span  style={{  fontWeight: 'bold',  color: 'red', }}>{emailError}</span><br/><br/>
           {/* <div style={formstyle} id="div1"></div><br></br><br/> */}

            <label >Password:  </label> 
            <input type="password"name ="password"  onChange={e => setPassword(e.target.value)}/>
            <div  id="div2"></div><br/><br/>

            <label >Confirm Password: </label> 
            <input type="password"name ="confirmPassword"  onChange={e=>setconfirmPassword(e.target.value)} onBlur={resetpassword}/><br/><span  style={{  fontWeight: 'bold',  color: 'red', }}>{repassworderr}</span><br/><br/>
           

            <input type="submit" value="submit"/><br></br><br/>
            <div id="div3" style={{color:'red',fontSize:30}}></div>
            </div><br/>
           
           
            {/* <div id="div1">{this.list}</div> */}
            </form>
            </body>
</>
)
}